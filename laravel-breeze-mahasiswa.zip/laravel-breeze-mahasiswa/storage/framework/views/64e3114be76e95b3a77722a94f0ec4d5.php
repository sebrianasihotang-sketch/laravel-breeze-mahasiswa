<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> 

        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Detail Mahasiswa
        </h2>

     <?php $__env->endSlot(); ?>


    <div class="py-8">

        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">

            <div class="bg-white shadow-sm rounded-xl">

                <div class="p-6">

                    <table class="w-full">

                        <tr class="border-b">
                            <td class="py-3 font-semibold w-1/3">
                                NIM
                            </td>
                            <td>
                                <?php echo e($mahasiswa->nim); ?>

                            </td>
                        </tr>

                        <tr class="border-b">
                            <td class="py-3 font-semibold">
                                Nama Mahasiswa
                            </td>
                            <td>
                                <?php echo e($mahasiswa->nama_mahasiswa); ?>

                            </td>
                        </tr>

                        <tr class="border-b">
                            <td class="py-3 font-semibold">
                                Tempat Lahir
                            </td>
                            <td>
                                <?php echo e($mahasiswa->tempat_lahir); ?>

                            </td>
                        </tr>

                        <tr class="border-b">
                            <td class="py-3 font-semibold">
                                Tanggal Lahir
                            </td>
                            <td>
                                <?php echo e($mahasiswa->tanggal_lahir->format('d-m-Y')); ?>

                            </td>
                        </tr>

                        <tr class="border-b">
                            <td class="py-3 font-semibold">
                                Jenis Kelamin
                            </td>
                            <td>
                                <?php echo e($mahasiswa->jenis_kelamin); ?>

                            </td>
                        </tr>

                        <tr class="border-b">
                            <td class="py-3 font-semibold">
                                Alamat
                            </td>
                            <td>
                                <?php echo e($mahasiswa->alamat); ?>

                            </td>
                        </tr>

                        <tr class="border-b">
                            <td class="py-3 font-semibold">
                                Program Studi
                            </td>
                            <td>
                                <?php echo e($mahasiswa->program_studi); ?>

                            </td>
                        </tr>

                        <tr class="border-b">
                            <td class="py-3 font-semibold">
                                Nomor HP
                            </td>
                            <td>
                                <?php echo e($mahasiswa->nomor_hp); ?>

                            </td>
                        </tr>

                        <tr>
                            <td class="py-3 font-semibold">
                                E-mail
                            </td>
                            <td>
                                <?php echo e($mahasiswa->email); ?>

                            </td>
                        </tr>

                    </table>


                    <div class="mt-6 flex gap-3">

                        <a href="<?php echo e(route('mahasiswa.edit', $mahasiswa->id)); ?>"
                           class="px-5 py-2.5
                                  bg-yellow-500 text-white
                                  rounded-lg font-semibold
                                  hover:bg-yellow-600">

                            Edit

                        </a>


                        <a href="<?php echo e(route('mahasiswa.index')); ?>"
                           class="px-5 py-2.5
                                  bg-gray-500 text-white
                                  rounded-lg font-semibold
                                  hover:bg-gray-600">

                            Kembali

                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel-breeze-mahasiswa\resources\views/mahasiswa/show.blade.php ENDPATH**/ ?>