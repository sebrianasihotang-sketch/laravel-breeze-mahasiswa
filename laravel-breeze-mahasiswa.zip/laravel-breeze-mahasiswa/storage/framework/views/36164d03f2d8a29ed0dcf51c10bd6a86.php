<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Create Data Mahasiswa
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">

        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">

            <div style="
                background:white;
                padding:25px;
                border-radius:10px;
                box-shadow:0 2px 8px rgba(0,0,0,.08);
            ">

                <?php if($errors->any()): ?>

                    <div style="
                        background:#fee2e2;
                        color:#991b1b;
                        padding:15px;
                        border-radius:8px;
                        margin-bottom:20px;
                    ">

                        <strong>Data belum benar:</strong>

                        <ul style="margin-top:8px;">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                    </div>

                <?php endif; ?>


                <form action="<?php echo e(route('mahasiswa.store')); ?>"
                      method="POST">

                    <?php echo csrf_field(); ?>


                    
                    <div style="margin-bottom:18px;">

                        <label>NIM</label>

                        <input type="text"
                               name="nim"
                               value="<?php echo e(old('nim')); ?>"
                               placeholder="Masukkan NIM"
                               style="
                                   width:100%;
                                   padding:10px;
                                   border:1px solid #d1d5db;
                                   border-radius:6px;
                                   margin-top:6px;
                                   box-sizing:border-box;
                               ">

                        <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color:#dc2626;font-size:13px;">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    
                    <div style="margin-bottom:18px;">

                        <label>Nama Mahasiswa</label>

                        <input type="text"
                               name="nama_mahasiswa"
                               value="<?php echo e(old('nama_mahasiswa')); ?>"
                               placeholder="Masukkan nama mahasiswa"
                               style="
                                   width:100%;
                                   padding:10px;
                                   border:1px solid #d1d5db;
                                   border-radius:6px;
                                   margin-top:6px;
                                   box-sizing:border-box;
                               ">

                        <?php $__errorArgs = ['nama_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color:#dc2626;font-size:13px;">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    
                    <div style="margin-bottom:18px;">

                        <label>Tempat Lahir</label>

                        <input type="text"
                               name="tempat_lahir"
                               value="<?php echo e(old('tempat_lahir')); ?>"
                               placeholder="Masukkan tempat lahir"
                               style="
                                   width:100%;
                                   padding:10px;
                                   border:1px solid #d1d5db;
                                   border-radius:6px;
                                   margin-top:6px;
                                   box-sizing:border-box;
                               ">

                        <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color:#dc2626;font-size:13px;">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    
                    <div style="margin-bottom:18px;">

                        <label>Tanggal Lahir</label>

                        <input type="date"
                               name="tanggal_lahir"
                               value="<?php echo e(old('tanggal_lahir')); ?>"
                               style="
                                   width:100%;
                                   padding:10px;
                                   border:1px solid #d1d5db;
                                   border-radius:6px;
                                   margin-top:6px;
                                   box-sizing:border-box;
                               ">

                        <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color:#dc2626;font-size:13px;">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    
                    <div style="margin-bottom:18px;">

                        <label>Jenis Kelamin</label>

                        <select name="jenis_kelamin"
                                style="
                                    width:100%;
                                    padding:10px;
                                    border:1px solid #d1d5db;
                                    border-radius:6px;
                                    margin-top:6px;
                                    box-sizing:border-box;
                                ">

                            <option value="">
                                -- Pilih Jenis Kelamin --
                            </option>

                            <option value="Laki-laki">
                                Laki-laki
                            </option>

                            <option value="Perempuan">
                                Perempuan
                            </option>

                        </select>

                        <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color:#dc2626;font-size:13px;">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    
                    <div style="margin-bottom:18px;">

                        <label>Alamat</label>

                        <textarea name="alamat"
                                  rows="4"
                                  placeholder="Masukkan alamat"
                                  style="
                                      width:100%;
                                      padding:10px;
                                      border:1px solid #d1d5db;
                                      border-radius:6px;
                                      margin-top:6px;
                                      box-sizing:border-box;
                                  "><?php echo e(old('alamat')); ?></textarea>

                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color:#dc2626;font-size:13px;">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    
                    <div style="margin-bottom:18px;">

                        <label>Program Studi</label>

                        <input type="text"
                               name="program_studi"
                               value="<?php echo e(old('program_studi')); ?>"
                               placeholder="Masukkan program studi"
                               style="
                                   width:100%;
                                   padding:10px;
                                   border:1px solid #d1d5db;
                                   border-radius:6px;
                                   margin-top:6px;
                                   box-sizing:border-box;
                               ">

                        <?php $__errorArgs = ['program_studi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color:#dc2626;font-size:13px;">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    
                    <div style="margin-bottom:18px;">

                        <label>Nomor HP</label>

                        <input type="text"
                               name="nomor_hp"
                               value="<?php echo e(old('nomor_hp')); ?>"
                               placeholder="Masukkan nomor HP"
                               style="
                                   width:100%;
                                   padding:10px;
                                   border:1px solid #d1d5db;
                                   border-radius:6px;
                                   margin-top:6px;
                                   box-sizing:border-box;
                               ">

                        <?php $__errorArgs = ['nomor_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color:#dc2626;font-size:13px;">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    
                    <div style="margin-bottom:25px;">

                        <label>E-mail</label>

                        <input type="email"
                               name="email"
                               value="<?php echo e(old('email')); ?>"
                               placeholder="Masukkan email"
                               style="
                                   width:100%;
                                   padding:10px;
                                   border:1px solid #d1d5db;
                                   border-radius:6px;
                                   margin-top:6px;
                                   box-sizing:border-box;
                               ">

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color:#dc2626;font-size:13px;">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    
                    <div style="
                        display:flex;
                        gap:10px;
                    ">

                        <button type="submit"
                                style="
                                    background:#2563eb;
                                    color:white;
                                    border:none;
                                    padding:11px 22px;
                                    border-radius:7px;
                                    font-weight:700;
                                    cursor:pointer;
                                ">
                            SIMPAN DATA
                        </button>


                        <a href="<?php echo e(route('mahasiswa.index')); ?>"
                           style="
                               background:#6b7280;
                               color:white;
                               text-decoration:none;
                               padding:11px 22px;
                               border-radius:7px;
                               font-weight:700;
                           ">
                            BATAL
                        </a>

                    </div>

                </form>

            </div>

        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel-breeze-mahasiswa\resources\views/mahasiswa/create.blade.php ENDPATH**/ ?>