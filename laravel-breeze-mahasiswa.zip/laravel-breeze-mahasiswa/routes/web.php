<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\MahasiswaController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Saat membuka website utama,
// langsung diarahkan ke halaman mahasiswa.
// Karena halaman mahasiswa memakai auth,
// user yang belum login akan diarahkan ke login.
Route::get('/', function () {
    return redirect()->route('mahasiswa.index');
});


// Dashboard Breeze tetap ada,
// tetapi setelah login dashboard langsung diarahkan
// ke halaman Data Mahasiswa.
Route::get('/dashboard', function () {
    return redirect()->route('mahasiswa.index');
})->middleware(['auth'])->name('dashboard');


// CRUD Mahasiswa
// Hanya user yang sudah login yang bisa mengakses.
Route::middleware(['auth'])->group(function () {

    Route::resource('mahasiswa', MahasiswaController::class);

});


// Profile Breeze
Route::middleware('auth')->group(function () {

    Route::get('/profile', [ProfileController::class, 'edit'])
        ->name('profile.edit');

    Route::patch('/profile', [ProfileController::class, 'update'])
        ->name('profile.update');

    Route::delete('/profile', [ProfileController::class, 'destroy'])
        ->name('profile.destroy');

});


// Breeze Authentication
require __DIR__.'/auth.php';