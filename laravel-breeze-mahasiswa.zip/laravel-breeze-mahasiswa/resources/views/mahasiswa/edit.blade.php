<x-app-layout>

    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Update Data Mahasiswa
        </h2>
    </x-slot>

    <div class="py-6">

        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">

            <div style="
                background:white;
                padding:25px;
                border-radius:10px;
                box-shadow:0 2px 8px rgba(0,0,0,.08);
            ">

                @if ($errors->any())

                    <div style="
                        background:#fee2e2;
                        color:#991b1b;
                        padding:15px;
                        border-radius:8px;
                        margin-bottom:20px;
                    ">

                        <strong>Data belum benar:</strong>

                        <ul style="margin-top:8px;">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>

                    </div>

                @endif


                <form action="{{ route('mahasiswa.update', $mahasiswa->id) }}"
                      method="POST">

                    @csrf

                    @method('PUT')


                    {{-- NIM --}}
                    <div style="margin-bottom:18px;">

                        <label>NIM</label>

                        <input type="text"
                               name="nim"
                               value="{{ old('nim', $mahasiswa->nim) }}"
                               style="
                                   width:100%;
                                   padding:10px;
                                   border:1px solid #d1d5db;
                                   border-radius:6px;
                                   margin-top:6px;
                                   box-sizing:border-box;
                               ">

                        @error('nim')
                            <div style="color:#dc2626;font-size:13px;">
                                {{ $message }}
                            </div>
                        @enderror

                    </div>


                    {{-- NAMA --}}
                    <div style="margin-bottom:18px;">

                        <label>Nama Mahasiswa</label>

                        <input type="text"
                               name="nama_mahasiswa"
                               value="{{ old('nama_mahasiswa', $mahasiswa->nama_mahasiswa) }}"
                               style="
                                   width:100%;
                                   padding:10px;
                                   border:1px solid #d1d5db;
                                   border-radius:6px;
                                   margin-top:6px;
                                   box-sizing:border-box;
                               ">

                        @error('nama_mahasiswa')
                            <div style="color:#dc2626;font-size:13px;">
                                {{ $message }}
                            </div>
                        @enderror

                    </div>


                    {{-- TEMPAT LAHIR --}}
                    <div style="margin-bottom:18px;">

                        <label>Tempat Lahir</label>

                        <input type="text"
                               name="tempat_lahir"
                               value="{{ old('tempat_lahir', $mahasiswa->tempat_lahir) }}"
                               style="
                                   width:100%;
                                   padding:10px;
                                   border:1px solid #d1d5db;
                                   border-radius:6px;
                                   margin-top:6px;
                                   box-sizing:border-box;
                               ">

                        @error('tempat_lahir')
                            <div style="color:#dc2626;font-size:13px;">
                                {{ $message }}
                            </div>
                        @enderror

                    </div>


                    {{-- TANGGAL LAHIR --}}
                    <div style="margin-bottom:18px;">

                        <label>Tanggal Lahir</label>

                        <input type="date"
                               name="tanggal_lahir"
                               value="{{ old('tanggal_lahir', $mahasiswa->tanggal_lahir->format('Y-m-d')) }}"
                               style="
                                   width:100%;
                                   padding:10px;
                                   border:1px solid #d1d5db;
                                   border-radius:6px;
                                   margin-top:6px;
                                   box-sizing:border-box;
                               ">

                        @error('tanggal_lahir')
                            <div style="color:#dc2626;font-size:13px;">
                                {{ $message }}
                            </div>
                        @enderror

                    </div>


                    {{-- JENIS KELAMIN --}}
                    <div style="margin-bottom:18px;">

                        <label>Jenis Kelamin</label>

                        <select name="jenis_kelamin"
                                style="
                                    width:100%;
                                    padding:10px;
                                    border:1px solid #d1d5db;
                                    border-radius:6px;
                                    margin-top:6px;
                                    box-sizing:border-box;
                                ">

                            <option value="Laki-laki"
                                {{ old('jenis_kelamin', $mahasiswa->jenis_kelamin) == 'Laki-laki' ? 'selected' : '' }}>
                                Laki-laki
                            </option>

                            <option value="Perempuan"
                                {{ old('jenis_kelamin', $mahasiswa->jenis_kelamin) == 'Perempuan' ? 'selected' : '' }}>
                                Perempuan
                            </option>

                        </select>

                        @error('jenis_kelamin')
                            <div style="color:#dc2626;font-size:13px;">
                                {{ $message }}
                            </div>
                        @enderror

                    </div>


                    {{-- ALAMAT --}}
                    <div style="margin-bottom:18px;">

                        <label>Alamat</label>

                        <textarea name="alamat"
                                  rows="4"
                                  style="
                                      width:100%;
                                      padding:10px;
                                      border:1px solid #d1d5db;
                                      border-radius:6px;
                                      margin-top:6px;
                                      box-sizing:border-box;
                                  ">{{ old('alamat', $mahasiswa->alamat) }}</textarea>

                        @error('alamat')
                            <div style="color:#dc2626;font-size:13px;">
                                {{ $message }}
                            </div>
                        @enderror

                    </div>


                    {{-- PROGRAM STUDI --}}
                    <div style="margin-bottom:18px;">

                        <label>Program Studi</label>

                        <input type="text"
                               name="program_studi"
                               value="{{ old('program_studi', $mahasiswa->program_studi) }}"
                               style="
                                   width:100%;
                                   padding:10px;
                                   border:1px solid #d1d5db;
                                   border-radius:6px;
                                   margin-top:6px;
                                   box-sizing:border-box;
                               ">

                        @error('program_studi')
                            <div style="color:#dc2626;font-size:13px;">
                                {{ $message }}
                            </div>
                        @enderror

                    </div>


                    {{-- NOMOR HP --}}
                    <div style="margin-bottom:18px;">

                        <label>Nomor HP</label>

                        <input type="text"
                               name="nomor_hp"
                               value="{{ old('nomor_hp', $mahasiswa->nomor_hp) }}"
                               style="
                                   width:100%;
                                   padding:10px;
                                   border:1px solid #d1d5db;
                                   border-radius:6px;
                                   margin-top:6px;
                                   box-sizing:border-box;
                               ">

                        @error('nomor_hp')
                            <div style="color:#dc2626;font-size:13px;">
                                {{ $message }}
                            </div>
                        @enderror

                    </div>


                    {{-- EMAIL --}}
                    <div style="margin-bottom:25px;">

                        <label>E-mail</label>

                        <input type="email"
                               name="email"
                               value="{{ old('email', $mahasiswa->email) }}"
                               style="
                                   width:100%;
                                   padding:10px;
                                   border:1px solid #d1d5db;
                                   border-radius:6px;
                                   margin-top:6px;
                                   box-sizing:border-box;
                               ">

                        @error('email')
                            <div style="color:#dc2626;font-size:13px;">
                                {{ $message }}
                            </div>
                        @enderror

                    </div>


                    {{-- BUTTON UPDATE --}}
                    <div style="
                        display:flex;
                        gap:10px;
                    ">

                        <button type="submit"
                                style="
                                    background:#16a34a;
                                    color:white;
                                    border:none;
                                    padding:11px 22px;
                                    border-radius:7px;
                                    font-weight:700;
                                    cursor:pointer;
                                ">
                            SIMPAN UPDATE
                        </button>


                        <a href="{{ route('mahasiswa.index') }}"
                           style="
                               background:#6b7280;
                               color:white;
                               text-decoration:none;
                               padding:11px 22px;
                               border-radius:7px;
                               font-weight:700;
                           ">
                            BATAL
                        </a>

                    </div>

                </form>

            </div>

        </div>

    </div>

</x-app-layout>