<x-app-layout>

    <style>
        body {
            background: #f7f8fc;
        }

        .page-wrapper {
            width: 100%;
        }

        .main-card {
            background: #ffffff;
            border: 1px solid #e9eaf2;
            border-radius: 18px;
            box-shadow: 0 8px 30px rgba(60, 72, 88, 0.06);
            overflow: hidden;
        }

        .card-header-custom {
            padding: 24px 28px;
            border-bottom: 1px solid #eef0f5;
            background: linear-gradient(to bottom, #ffffff, #fcfcfe);
        }

        .title-area h3 {
            margin: 0;
            font-size: 21px;
            font-weight: 700;
            color: #283044;
        }

        .title-area p {
            margin: 6px 0 0;
            font-size: 13px;
            color: #898b8f;
        }

        .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
        }

        .btn-create {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 10px 18px;
            background: #e9edff;
            color: #4f5fa8;
            border: 1px solid #dce2ff;
            border-radius: 10px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 700;
            transition: all 0.2s ease;
            white-space: nowrap;
        }

        .btn-create:hover {
            background: #dfe5ff;
            color: #435298;
        }

        .table-area {
            padding: 22px;
        }

        .table-container {
            width: 100%;
        }

        .mahasiswa-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            table-layout: fixed;
            font-size: 11px;
            color: #606266;
        }

        .mahasiswa-table th {
            background: #f8f9fc;
            color: #646c7d;
            font-weight: 700;
            text-align: center;
            padding: 13px 7px;
            border-top: 1px solid #eceef4;
            border-bottom: 1px solid #eceef4;
        }

        .mahasiswa-table th:first-child {
            border-left: 1px solid #eceef4;
            border-top-left-radius: 10px;
        }

        .mahasiswa-table th:last-child {
            border-right: 1px solid #eceef4;
            border-top-right-radius: 10px;
        }

        .mahasiswa-table td {
            background: #ffffff;
            padding: 13px 7px;
            border-bottom: 1px solid #f0f1f5;
            vertical-align: top;
            word-break: break-word;
        }

        .mahasiswa-table td:first-child {
            border-left: 1px solid #eceef4;
        }

        .mahasiswa-table td:last-child {
            border-right: 1px solid #eceef4;
        }

        .mahasiswa-table tbody tr:last-child td:first-child {
            border-bottom-left-radius: 10px;
        }

        .mahasiswa-table tbody tr:last-child td:last-child {
            border-bottom-right-radius: 10px;
        }

        .mahasiswa-table tbody tr:hover td {
            background: #fafbff;
        }

        .nim-text {
            color: #5866a8;
            font-weight: 700;
        }

        .nama-text {
            color: #2f3748;
            font-weight: 600;
        }

        .secondary-text {
            color: #8b93a4;
            font-size: 10px;
            margin-top: 4px;
        }

        .gender-badge {
            display: inline-block;
            padding: 5px 8px;
            border-radius: 20px;
            background: #f1efff;
            color: #756ab3;
            font-weight: 600;
            font-size: 10px;
        }

        .contact-email {
            color: #7c8495;
            margin-top: 4px;
            font-size: 10px;
        }

        .action-wrapper {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .btn-action {
            display: block;
            width: 100%;
            padding: 7px 4px;
            border-radius: 7px;
            text-align: center;
            text-decoration: none;
            font-size: 10px;
            font-weight: 700;
            transition: all 0.2s ease;
            box-sizing: border-box;
        }

        .btn-detail {
            background: #f0f2f7;
            color: #626a7d;
            border: 1px solid #e5e8ef;
        }

        .btn-detail:hover {
            background: #e5e8ef;
        }

        .btn-update {
            background: #fff4df;
            color: #b17b2d;
            border: 1px solid #f9e6bf;
        }

        .btn-update:hover {
            background: #ffecc7;
        }

        .btn-delete {
            width: 100%;
            padding: 7px 4px;
            border: 1px solid #f4d7da;
            border-radius: 7px;
            background: #fff0f1;
            color: #bc626c;
            font-size: 10px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .btn-delete:hover {
            background: #ffe3e5;
        }

        .empty-data {
            text-align: center;
            padding: 35px !important;
            color: #9299a8;
        }

        .success-message {
            margin-bottom: 18px;
            padding: 12px 16px;
            border-radius: 10px;
            background: #effaf4;
            border: 1px solid #d6f0df;
            color: #4d8a63;
            font-size: 13px;
        }

        .required-note {
            font-size: 11px;
            color: #9aa1af;
            margin-top: 14px;
        }

        @media (max-width: 1000px) {
            .header-content {
                flex-direction: column;
                align-items: stretch;
            }

            .btn-create {
                width: 100%;
            }

            .mahasiswa-table {
                font-size: 9px;
            }

            .mahasiswa-table th,
            .mahasiswa-table td {
                padding: 8px 4px;
            }
        }
    </style>


    {{-- HEADER BREEZE --}}
    <x-slot name="header">

        <div>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Data Mahasiswa
            </h2>

            <p class="text-sm text-gray-500 mt-1">
                Kelola data mahasiswa dengan mudah
            </p>
        </div>

    </x-slot>


    <div class="py-8">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <div class="page-wrapper">


                {{-- PESAN SUCCESS --}}
                @if (session('success'))

                    <div class="success-message">
                        {{ session('success') }}
                    </div>

                @endif


                {{-- CARD --}}
                <div class="main-card">


                    {{-- HEADER CARD --}}
                    <div class="card-header-custom">

                        <div class="header-content">

                            <div class="title-area">

                                <h3>
                                    Daftar Mahasiswa
                                </h3>

                                <p>
                                    Total
                                    <strong>{{ $mahasiswa->count() }}</strong>
                                    data mahasiswa tersimpan
                                </p>

                            </div>


                            {{-- SATU-SATUNYA CREATE --}}
                            <a href="{{ route('mahasiswa.create') }}"
                               class="btn-create">

                                + Tambah Mahasiswa

                            </a>

                        </div>

                    </div>


                    {{-- TABLE --}}
                    <div class="table-area">

                        <div class="table-container">

                            <table class="mahasiswa-table">

                                <thead>

                                    <tr>

                                        <th style="width: 4%;">
                                            No
                                        </th>

                                        <th style="width: 8%;">
                                            NIM
                                        </th>

                                        <th style="width: 12%;">
                                            Nama<br>Mahasiswa
                                        </th>

                                        <th style="width: 10%;">
                                            Tempat<br>Lahir
                                        </th>

                                        <th style="width: 8%;">
                                            Tanggal<br>Lahir
                                        </th>

                                        <th style="width: 8%;">
                                            Jenis<br>Kelamin
                                        </th>

                                        <th style="width: 13%;">
                                            Alamat
                                        </th>

                                        <th style="width: 11%;">
                                            Program<br>Studi
                                        </th>

                                        <th style="width: 9%;">
                                            Nomor<br>HP
                                        </th>

                                        <th style="width: 11%;">
                                            E-mail
                                        </th>

                                        <th style="width: 16%;">
                                            Aksi
                                        </th>

                                    </tr>

                                </thead>


                                <tbody>

                                    @forelse ($mahasiswa as $mhs)

                                        <tr>


                                            {{-- NO --}}
                                            <td style="text-align:center;">
                                                {{ $loop->iteration }}
                                            </td>


                                            {{-- NIM --}}
                                            <td style="text-align:center;">
                                                <span class="nim-text">
                                                    {{ $mhs->nim }}
                                                </span>
                                            </td>


                                            {{-- NAMA --}}
                                            <td>
                                                <span class="nama-text">
                                                    {{ $mhs->nama_mahasiswa }}
                                                </span>
                                            </td>


                                            {{-- TEMPAT LAHIR --}}
                                            <td>
                                                {{ $mhs->tempat_lahir }}
                                            </td>


                                            {{-- TANGGAL LAHIR --}}
                                            <td style="text-align:center;">
                                                {{ $mhs->tanggal_lahir->format('d-m-Y') }}
                                            </td>


                                            {{-- JENIS KELAMIN --}}
                                            <td style="text-align:center;">

                                                <span class="gender-badge">
                                                    {{ $mhs->jenis_kelamin }}
                                                </span>

                                            </td>


                                            {{-- ALAMAT --}}
                                            <td>
                                                {{ $mhs->alamat }}
                                            </td>


                                            {{-- PROGRAM STUDI --}}
                                            <td>
                                                {{ $mhs->program_studi }}
                                            </td>


                                            {{-- NOMOR HP --}}
                                            <td style="text-align:center;">
                                                {{ $mhs->nomor_hp }}
                                            </td>


                                            {{-- EMAIL --}}
                                            <td>
                                                <span class="contact-email">
                                                    {{ $mhs->email }}
                                                </span>
                                            </td>


                                            {{-- AKSI --}}
                                            <td>

                                                <div class="action-wrapper">


                                                    {{-- DETAIL --}}
                                                    <a href="{{ route('mahasiswa.show', $mhs->id) }}"
                                                       class="btn-action btn-detail">

                                                        DETAIL

                                                    </a>


                                                    {{-- UPDATE --}}
                                                    <a href="{{ route('mahasiswa.edit', $mhs->id) }}"
                                                       class="btn-action btn-update">

                                                        UPDATE

                                                    </a>


                                                    {{-- DELETE --}}
                                                    <form action="{{ route('mahasiswa.destroy', $mhs->id) }}"
                                                          method="POST"
                                                          onsubmit="return confirm('Apakah kamu yakin ingin menghapus data mahasiswa ini?');">

                                                        @csrf

                                                        @method('DELETE')

                                                        <button type="submit"
                                                                class="btn-delete">

                                                            DELETE

                                                        </button>

                                                    </form>

                                                </div>

                                            </td>

                                        </tr>

                                    @empty

                                        <tr>

                                            <td colspan="11"
                                                class="empty-data">

                                                Belum ada data mahasiswa.

                                            </td>

                                        </tr>

                                    @endforelse

                                </tbody>

                            </table>

                        </div>


                        <div class="required-note">
                            Data mahasiswa meliputi NIM, nama, tempat/tanggal lahir,
                            jenis kelamin, alamat, program studi, nomor HP, dan e-mail.
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</x-app-layout>