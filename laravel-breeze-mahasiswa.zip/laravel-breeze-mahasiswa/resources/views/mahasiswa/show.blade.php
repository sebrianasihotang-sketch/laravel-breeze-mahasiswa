<x-app-layout>

    <x-slot name="header">

        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Detail Mahasiswa
        </h2>

    </x-slot>


    <div class="py-8">

        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">

            <div class="bg-white shadow-sm rounded-xl">

                <div class="p-6">

                    <table class="w-full">

                        <tr class="border-b">
                            <td class="py-3 font-semibold w-1/3">
                                NIM
                            </td>
                            <td>
                                {{ $mahasiswa->nim }}
                            </td>
                        </tr>

                        <tr class="border-b">
                            <td class="py-3 font-semibold">
                                Nama Mahasiswa
                            </td>
                            <td>
                                {{ $mahasiswa->nama_mahasiswa }}
                            </td>
                        </tr>

                        <tr class="border-b">
                            <td class="py-3 font-semibold">
                                Tempat Lahir
                            </td>
                            <td>
                                {{ $mahasiswa->tempat_lahir }}
                            </td>
                        </tr>

                        <tr class="border-b">
                            <td class="py-3 font-semibold">
                                Tanggal Lahir
                            </td>
                            <td>
                                {{ $mahasiswa->tanggal_lahir->format('d-m-Y') }}
                            </td>
                        </tr>

                        <tr class="border-b">
                            <td class="py-3 font-semibold">
                                Jenis Kelamin
                            </td>
                            <td>
                                {{ $mahasiswa->jenis_kelamin }}
                            </td>
                        </tr>

                        <tr class="border-b">
                            <td class="py-3 font-semibold">
                                Alamat
                            </td>
                            <td>
                                {{ $mahasiswa->alamat }}
                            </td>
                        </tr>

                        <tr class="border-b">
                            <td class="py-3 font-semibold">
                                Program Studi
                            </td>
                            <td>
                                {{ $mahasiswa->program_studi }}
                            </td>
                        </tr>

                        <tr class="border-b">
                            <td class="py-3 font-semibold">
                                Nomor HP
                            </td>
                            <td>
                                {{ $mahasiswa->nomor_hp }}
                            </td>
                        </tr>

                        <tr>
                            <td class="py-3 font-semibold">
                                E-mail
                            </td>
                            <td>
                                {{ $mahasiswa->email }}
                            </td>
                        </tr>

                    </table>


                    <div class="mt-6 flex gap-3">

                        <a href="{{ route('mahasiswa.edit', $mahasiswa->id) }}"
                           class="px-5 py-2.5
                                  bg-yellow-500 text-white
                                  rounded-lg font-semibold
                                  hover:bg-yellow-600">

                            Edit

                        </a>


                        <a href="{{ route('mahasiswa.index') }}"
                           class="px-5 py-2.5
                                  bg-gray-500 text-white
                                  rounded-lg font-semibold
                                  hover:bg-gray-600">

                            Kembali

                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>

</x-app-layout>